import React, { useState } from 'react';
import {
  Portfolio,
  Holding,
  Instrument,
  MarketPrice,
  TargetAllocation,
  FeeSchedule,
  Constraint,
  AssetClass
} from '../types';
import { simulatePortfolioRebalance } from '../engine/rebalancer';
import { formatINR } from '../utils/formatters';
import { ArrowUpRight, ArrowDownRight, CheckCircle2, AlertTriangle, ShieldCheck, RefreshCw } from 'lucide-react';

interface CustomerViewProps {
  portfolios: Portfolio[];
  holdings: Holding[];
  instruments: Map<string, Instrument>;
  latestPrices: Map<string, MarketPrice>;
  targetAllocations: Map<string, TargetAllocation>;
  feeSchedule: FeeSchedule;
  constraints: Constraint[];
  onExecuteProposal: (portfolioId: string, tradeCount: number) => void;
}

const ASSET_CLASS_LABELS: Record<AssetClass, string> = {
  US_EQUITY: 'Indian Large-Cap (Nifty 50)',
  INTL_EQUITY: 'International Equity (Nasdaq 100)',
  EM_EQUITY: 'Indian Midcap (Nifty Midcap 150)',
  FIXED_INCOME: 'G-Sec & Bharat Bond Sovereign',
  REAL_ESTATE: 'Commercial REITs (Embassy)',
  COMMODITIES: 'Gold & Silver BeES',
  CASH_EQUIVALENT: 'Liquid BeES Overnight TREPS'
};

const ASSET_CLASS_COLORS: Record<AssetClass, string> = {
  US_EQUITY: 'bg-blue-500',
  INTL_EQUITY: 'bg-indigo-500',
  EM_EQUITY: 'bg-purple-500',
  FIXED_INCOME: 'bg-emerald-500',
  REAL_ESTATE: 'bg-amber-500',
  COMMODITIES: 'bg-orange-500',
  CASH_EQUIVALENT: 'bg-slate-400'
};

export const CustomerView: React.FC<CustomerViewProps> = ({
  portfolios,
  holdings,
  instruments,
  latestPrices,
  targetAllocations,
  feeSchedule,
  constraints,
  onExecuteProposal
}) => {
  const [selectedPortId, setSelectedPortId] = useState<string>(portfolios[0]?.portfolio_id || '');
  const [isApproving, setIsApproving] = useState<boolean>(false);
  const [approvalSuccess, setApprovalSuccess] = useState<boolean>(false);

  const currentPortfolio = portfolios.find(p => p.portfolio_id === selectedPortId) || portfolios[0];
  const portHoldings = holdings.filter(h => h.portfolio_id === currentPortfolio?.portfolio_id);
  const targetModel = targetAllocations.get(currentPortfolio?.target_model_id) || Array.from(targetAllocations.values())[0];

  const simulation = currentPortfolio
    ? simulatePortfolioRebalance(
        currentPortfolio,
        portHoldings,
        instruments,
        latestPrices,
        targetModel,
        feeSchedule,
        constraints
      )
    : null;

  const handleApprove = () => {
    setIsApproving(true);
    setTimeout(() => {
      if (simulation) {
        onExecuteProposal(currentPortfolio.portfolio_id, simulation.proposed_trades.length);
      }
      setIsApproving(false);
      setApprovalSuccess(true);
      setTimeout(() => setApprovalSuccess(false), 4000);
    }, 600);
  };

  if (!currentPortfolio || !simulation) {
    return (
      <div className="p-8 text-center text-slate-400">
        No portfolio selected. Please generate a dataset from the Admin & Data Hub.
      </div>
    );
  }

  const assetClassKeys: AssetClass[] = [
    'US_EQUITY',
    'INTL_EQUITY',
    'EM_EQUITY',
    'FIXED_INCOME',
    'REAL_ESTATE',
    'COMMODITIES',
    'CASH_EQUIVALENT'
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
      {/* Portfolio Selector & Mandate Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">
            Account Holder View
          </span>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-1">
            {currentPortfolio.portfolio_name}
          </h1>
          <div className="flex items-center gap-3 text-xs text-slate-400 mt-2 font-mono">
            <span>ID: {currentPortfolio.portfolio_id}</span>
            <span>·</span>
            <span>Target Mandate: {targetModel.model_name}</span>
            <span>·</span>
            <span>Wrapper: {currentPortfolio.portfolio_type}</span>
          </div>
        </div>

        {/* Portfolio Dropdown Switcher */}
        <div className="flex items-center gap-3">
          <label htmlFor="port-select" className="text-xs text-slate-400 whitespace-nowrap">
            Switch Portfolio:
          </label>
          <select
            id="port-select"
            value={selectedPortId}
            onChange={e => setSelectedPortId(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-200 text-sm rounded-lg px-3 py-2 focus:ring-2 focus:ring-cyan-500 focus:outline-none"
          >
            {portfolios.slice(0, 30).map(p => (
              <option key={p.portfolio_id} value={p.portfolio_id}>
                {p.portfolio_name} ({p.portfolio_id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-400 font-medium">Total Portfolio Value</span>
          <div className="text-2xl font-bold text-white font-mono tabular-nums mt-2">
            {formatINR(simulation.total_portfolio_value)}
          </div>
          <span className="text-xs text-slate-500 mt-1 block">
            Holdings + Settled Cash Reserve
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-400 font-medium">Uninvested Cash Balance</span>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-2">
            {formatINR(simulation.cash_balance)}
          </div>
          <span className="text-xs text-slate-500 mt-1 block">
            {((simulation.cash_balance / simulation.total_portfolio_value) * 100).toFixed(1)}% of total assets
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-400 font-medium">Max Allocation Drift</span>
          <div className="flex items-center gap-2 mt-2">
            <span
              className={`text-2xl font-bold font-mono tabular-nums ${
                simulation.max_drift_pct > 8
                  ? 'text-rose-400'
                  : simulation.max_drift_pct > 4
                  ? 'text-amber-400'
                  : 'text-emerald-400'
              }`}
            >
              {simulation.max_drift_pct.toFixed(2)}%
            </span>
          </div>
          <span className="text-xs text-slate-500 mt-1 block font-mono">
            Tolerance threshold: ±{targetModel.rebalance_threshold_pct}%
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-400 font-medium">Proposed Rebalance Orders</span>
          <div className="text-2xl font-bold text-white font-mono tabular-nums mt-2">
            {simulation.proposed_trades.length} Orders
          </div>
          <span className="text-xs text-slate-500 mt-1 block">
            Est. levies: {formatINR(simulation.total_fees_usd)}
          </span>
        </div>
      </div>

      {/* Target Allocation vs Current Allocation Analysis */}
      <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
          <div>
            <h2 className="text-lg font-bold text-white">
              Target Allocation vs. Current Holdings
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Visual comparison of mandated asset weights against current market valuations.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-cyan-500 inline-block"></span>
              <span>Current Weight</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-slate-600 inline-block"></span>
              <span>Target Weight</span>
            </div>
          </div>
        </div>

        <div className="mt-6 space-y-5">
          {assetClassKeys.map(ac => {
            const current = simulation.current_allocations[ac];
            const target = targetModel.target_weights[ac] || 0;
            const drift = simulation.drift_by_asset_class[ac] || 0;
            const isOverweight = drift > 0;
            const exceedsTolerance = Math.abs(drift) > targetModel.rebalance_threshold_pct;

            return (
              <div key={ac} className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${ASSET_CLASS_COLORS[ac]}`}></span>
                    <span className="font-semibold text-slate-200">{ASSET_CLASS_LABELS[ac]}</span>
                  </div>

                  <div className="flex items-center gap-4 font-mono">
                    <span className="text-slate-400">
                      Target: <strong className="text-slate-300">{target.toFixed(1)}%</strong>
                    </span>
                    <span className="text-slate-300">
                      Current: <strong className="text-white">{current.weight.toFixed(1)}%</strong> ({formatINR(current.value)})
                    </span>
                    <span
                      className={`tabular-nums font-semibold flex items-center gap-0.5 ${
                        exceedsTolerance
                          ? isOverweight
                            ? 'text-amber-400'
                            : 'text-cyan-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {isOverweight ? (
                        <ArrowUpRight className="w-3.5 h-3.5 inline" />
                      ) : (
                        <ArrowDownRight className="w-3.5 h-3.5 inline" />
                      )}
                      {drift > 0 ? `+${drift.toFixed(1)}%` : `${drift.toFixed(1)}%`}
                    </span>
                  </div>
                </div>

                {/* Dual Progress Bars */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-cyan-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, current.weight)}%` }}
                    ></div>
                  </div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-slate-600 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, target)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Proposed Rebalancing Trades & Simulated Post-Trade Result */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trades Table */}
        <div className="lg:col-span-2 bg-slate-800/40 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-white">
                Proposed Rebalancing Orders
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Policy-filtered trades generated to re-align portfolio to target allocation.
              </p>
            </div>
            {simulation.proposed_trades.length > 0 && (
              <span className="text-xs text-slate-400 font-mono">
                {simulation.proposed_trades.length} trade recommendation(s)
              </span>
            )}
          </div>

          {simulation.proposed_trades.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <ShieldCheck className="w-8 h-8 mx-auto text-emerald-400" />
              <p className="text-sm font-medium text-slate-300">
                Portfolio is currently in tolerance!
              </p>
              <p className="text-xs text-slate-500">
                All asset class allocations are within the ±{targetModel.rebalance_threshold_pct}% policy band. No trades needed.
              </p>
            </div>
          ) : (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-medium">
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Security</th>
                    <th className="py-2.5 px-3 text-right">Shares</th>
                    <th className="py-2.5 px-3 text-right">Price</th>
                    <th className="py-2.5 px-3 text-right">Gross Est.</th>
                    <th className="py-2.5 px-3 text-right">Fee Est.</th>
                    <th className="py-2.5 px-3 text-right">Weight Change</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {simulation.proposed_trades.map(tr => {
                    const inst = instruments.get(tr.instrument_id);
                    return (
                      <tr key={tr.trade_id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3">
                          <span
                            className={`font-bold ${
                              tr.action === 'BUY' ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {tr.action}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-sans">
                          <div className="font-semibold text-slate-200">{inst?.ticker || tr.instrument_id}</div>
                          <div className="text-[10px] text-slate-400 truncate max-w-[150px]">
                            {inst?.asset_name}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right tabular-nums text-slate-200">
                          {tr.shares.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                          {formatINR(tr.limit_or_market_price)}
                        </td>
                        <td className="py-3 px-3 text-right tabular-nums text-slate-200">
                          {formatINR(tr.gross_amount_usd)}
                        </td>
                        <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                          {formatINR(tr.estimated_fee_usd)}
                        </td>
                        <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                          {tr.pre_weight_pct.toFixed(1)}% →{' '}
                          <strong className="text-white">{tr.post_weight_pct.toFixed(1)}%</strong>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Simulated Post-Trade Allocation Card */}
        <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">
              Simulated Post-Trade Impact
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Deterministic forecast of portfolio alignment after trade execution.
            </p>

            <div className="mt-6 space-y-4">
              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Max Drift Reduction</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    {simulation.max_drift_pct.toFixed(1)}% → {simulation.post_max_drift_pct.toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Post-Trade Cash Reserve</span>
                  <span className="font-mono text-cyan-300 font-bold">
                    {formatINR(simulation.cash_after_trades)}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Total Statutory / Broker Fees</span>
                  <span className="font-mono text-slate-300">
                    {formatINR(simulation.total_fees_usd)}
                  </span>
                </div>
              </div>

              {simulation.violations.length > 0 && (
                <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-900/50 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-rose-300 font-semibold">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    <span>Compliance Blockers Detected</span>
                  </div>
                  <p className="text-[11px] text-rose-200/80">
                    {simulation.violations[0].message}
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 mt-6">
            {approvalSuccess ? (
              <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-400 py-2.5 bg-emerald-950/30 border border-emerald-800/40 rounded-lg">
                <CheckCircle2 className="w-4 h-4" />
                <span>Proposal Approved & Queued for Execution</span>
              </div>
            ) : (
              <button
                disabled={isApproving || simulation.proposed_trades.length === 0 || simulation.violations.some(v => v.severity === 'CRITICAL_ERROR')}
                onClick={handleApprove}
                className="w-full py-2.5 px-4 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                {isApproving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Transmitting Orders...</span>
                  </>
                ) : (
                  <span>Approve & Authorize Rebalance</span>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
