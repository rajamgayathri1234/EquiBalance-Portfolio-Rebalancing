import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface StoredUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'CUSTOMER' | 'OPERATIONS' | 'COMPLIANCE' | 'ADMIN';
  salt: string;
  passwordHash: string;
  panNumber?: string;
  kycStatus: 'VERIFIED' | 'PENDING' | 'REJECTED';
  portfolioType?: string;
  createdAt: string;
  updatedAt: string;
}

const DB_DIR = path.resolve(process.cwd(), 'server', 'data');
const DB_FILE = path.join(DB_DIR, 'users.json');

// Ensure data directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

// Seed default users if database file does not exist
function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

const DEFAULT_USERS: StoredUser[] = [
  {
    id: 'USR-IN-001',
    name: 'Rajesh Sharma',
    email: 'rajesh.sharma@investor.in',
    phone: '+91 98112 34567',
    role: 'CUSTOMER',
    panNumber: 'ABCPS1234F',
    kycStatus: 'VERIFIED',
    portfolioType: 'DEMAT_INDIVIDUAL',
    salt: 'a1b2c3d4e5f60718293a4b5c6d7e8f90',
    passwordHash: hashPassword('Investor@2026', 'a1b2c3d4e5f60718293a4b5c6d7e8f90'),
    createdAt: '2024-01-15T09:00:00Z',
    updatedAt: '2024-01-15T09:00:00Z'
  },
  {
    id: 'USR-IN-002',
    name: 'Priya Patel',
    email: 'priya.patel@wealthops.in',
    phone: '+91 98223 45678',
    role: 'OPERATIONS',
    panNumber: 'BKPPA5678K',
    kycStatus: 'VERIFIED',
    salt: 'b2c3d4e5f60718293a4b5c6d7e8f90a1',
    passwordHash: hashPassword('OpsTeam@2026', 'b2c3d4e5f60718293a4b5c6d7e8f90a1'),
    createdAt: '2024-01-20T10:00:00Z',
    updatedAt: '2024-01-20T10:00:00Z'
  },
  {
    id: 'USR-IN-003',
    name: 'Arun Verma',
    email: 'arun.verma@compliance.in',
    phone: '+91 98334 56789',
    role: 'COMPLIANCE',
    panNumber: 'CKPVE9012M',
    kycStatus: 'VERIFIED',
    salt: 'c3d4e5f60718293a4b5c6d7e8f90a1b2',
    passwordHash: hashPassword('Compliance@2026', 'c3d4e5f60718293a4b5c6d7e8f90a1b2'),
    createdAt: '2024-02-01T11:00:00Z',
    updatedAt: '2024-02-01T11:00:00Z'
  },
  {
    id: 'USR-IN-004',
    name: 'Suresh Gupta (Admin)',
    email: 'admin@equibalance.in',
    phone: '+91 98445 67890',
    role: 'ADMIN',
    panNumber: 'DKPGU3456N',
    kycStatus: 'VERIFIED',
    salt: 'd4e5f60718293a4b5c6d7e8f90a1b2c3',
    passwordHash: hashPassword('AdminSecure@2026', 'd4e5f60718293a4b5c6d7e8f90a1b2c3'),
    createdAt: '2024-01-01T08:00:00Z',
    updatedAt: '2024-01-01T08:00:00Z'
  }
];

class UserDatabase {
  private users: StoredUser[] = [];

  constructor() {
    this.load();
  }

  private load(): void {
    try {
      if (fs.existsSync(DB_FILE)) {
        const data = fs.readFileSync(DB_FILE, 'utf-8');
        this.users = JSON.parse(data);
      } else {
        this.users = [...DEFAULT_USERS];
        this.save();
      }
    } catch (err) {
      console.error('Error loading users DB:', err);
      this.users = [...DEFAULT_USERS];
    }
  }

  private save(): void {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.users, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving users DB:', err);
    }
  }

  public findByEmail(email: string): StoredUser | undefined {
    return this.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  }

  public findById(id: string): StoredUser | undefined {
    return this.users.find(u => u.id === id);
  }

  public createUser(userData: {
    name: string;
    email: string;
    phone: string;
    role: 'CUSTOMER' | 'OPERATIONS' | 'COMPLIANCE' | 'ADMIN';
    password: string;
    panNumber?: string;
    portfolioType?: string;
  }): { success: boolean; user?: StoredUser; error?: string } {
    if (this.findByEmail(userData.email)) {
      return { success: false, error: 'An account with this email address already exists.' };
    }

    const salt = generateSalt();
    const passwordHash = hashPassword(userData.password, salt);
    const now = new Date().toISOString();

    const newUser: StoredUser = {
      id: `USR-${Date.now().toString().slice(-6)}`,
      name: userData.name.trim(),
      email: userData.email.trim().toLowerCase(),
      phone: userData.phone.trim(),
      role: userData.role,
      panNumber: userData.panNumber?.trim().toUpperCase(),
      portfolioType: userData.portfolioType || 'DEMAT_INDIVIDUAL',
      kycStatus: 'VERIFIED',
      salt,
      passwordHash,
      createdAt: now,
      updatedAt: now
    };

    this.users.push(newUser);
    this.save();
    return { success: true, user: newUser };
  }

  public verifyPassword(user: StoredUser, candidatePassword: string): boolean {
    try {
      const candidateHash = hashPassword(candidatePassword, user.salt);
      return crypto.timingSafeEqual(
        Buffer.from(candidateHash, 'hex'),
        Buffer.from(user.passwordHash, 'hex')
      );
    } catch {
      return false;
    }
  }

  public updatePassword(email: string, newPassword: string): boolean {
    const user = this.findByEmail(email);
    if (!user) return false;
    user.salt = generateSalt();
    user.passwordHash = hashPassword(newPassword, user.salt);
    user.updatedAt = new Date().toISOString();
    this.save();
    return true;
  }

  public getAllPublicProfiles(): Omit<StoredUser, 'salt' | 'passwordHash'>[] {
    return this.users.map(({ salt, passwordHash, ...rest }) => rest);
  }
}

export const userDb = new UserDatabase();
