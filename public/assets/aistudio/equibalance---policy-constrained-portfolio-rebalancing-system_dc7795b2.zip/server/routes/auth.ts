import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { userDb, StoredUser } from '../db';

const router = Router();

// In-memory active session tokens store
const activeSessions = new Map<string, { userId: string; expiresAt: number }>();

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// 1. REGISTRATION ENDPOINT
router.post('/register', (req: Request, res: Response) => {
  try {
    const { name, email, phone, password, confirmPassword, role, panNumber, portfolioType, privilegedKey } = req.body;

    // Validation: required fields
    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ success: false, error: 'Full legal name must be at least 2 characters.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || typeof email !== 'string' || !emailRegex.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    // Indian mobile number validation (10 digits, optional +91 prefix)
    const cleanPhone = String(phone || '').replace(/[\s\-+]/g, '');
    const mobileRegex = /^(?:91)?[6-9]\d{9}$/;
    if (!cleanPhone || !mobileRegex.test(cleanPhone)) {
      return res.status(400).json({
        success: false,
        error: 'Please enter a valid 10-digit Indian mobile number (e.g., 9876543210).'
      });
    }

    // Password validation
    if (!password || typeof password !== 'string' || password.length < 8) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 8 characters with letters and numbers.'
      });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ success: false, error: 'Password and Confirm Password do not match.' });
    }

    // Role validation: Privileged roles control
    let assignedRole: 'CUSTOMER' | 'OPERATIONS' | 'COMPLIANCE' | 'ADMIN' = 'CUSTOMER';
    const requestedRole = (role || 'CUSTOMER').toUpperCase();

    if (['OPERATIONS', 'COMPLIANCE', 'ADMIN'].includes(requestedRole)) {
      // In production/simulation, privileged roles require administrative authorization key
      const validAdminKeys = ['EQUI-PRIVILEGED-2026', 'ADMIN-SEBI-PASS', 'OPSTEAM-99'];
      if (!privilegedKey || !validAdminKeys.includes(privilegedKey.trim())) {
        return res.status(403).json({
          success: false,
          error: 'Privileged role assignment requires a valid Administrative Security Key. For public demo, use key: EQUI-PRIVILEGED-2026 or register as Customer.'
        });
      }
      assignedRole = requestedRole as any;
    } else {
      assignedRole = 'CUSTOMER';
    }

    // Create user in database with backend password hashing
    const result = userDb.createUser({
      name: name.trim(),
      email: email.trim(),
      phone: `+91 ${cleanPhone.slice(-10)}`,
      role: assignedRole,
      password,
      panNumber: panNumber ? String(panNumber).trim().toUpperCase() : undefined,
      portfolioType: portfolioType || 'DEMAT_INDIVIDUAL'
    });

    if (!result.success || !result.user) {
      return res.status(409).json({ success: false, error: result.error || 'Registration failed.' });
    }

    const { salt, passwordHash, ...publicUser } = result.user;
    return res.status(201).json({
      success: true,
      message: 'Account registered successfully! Redirecting to Login...',
      user: publicUser
    });
  } catch (err: any) {
    console.error('Registration API error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error during registration.' });
  }
});

// 2. LOGIN ENDPOINT
router.post('/login', (req: Request, res: Response) => {
  try {
    const { email, password, rememberMe } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required.' });
    }

    const user = userDb.findByEmail(email);
    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    const isMatch = userDb.verifyPassword(user, password);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    // Generate secure session token
    const token = generateToken();
    const durationMs = rememberMe ? 30 * 24 * 3600 * 1000 : 24 * 3600 * 1000; // 30 days or 1 day
    activeSessions.set(token, {
      userId: user.id,
      expiresAt: Date.now() + durationMs
    });

    const { salt, passwordHash, ...publicUser } = user;

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: publicUser
    });
  } catch (err: any) {
    console.error('Login API error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error during login.' });
  }
});

// 3. GET CURRENT USER PROFILE
router.get('/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Not authenticated.' });
  }

  const token = authHeader.substring(7);
  const session = activeSessions.get(token);

  if (!session || session.expiresAt < Date.now()) {
    if (session) activeSessions.delete(token);
    return res.status(401).json({ success: false, error: 'Session expired. Please log in again.' });
  }

  const user = userDb.findById(session.userId);
  if (!user) {
    activeSessions.delete(token);
    return res.status(401).json({ success: false, error: 'User no longer exists.' });
  }

  const { salt, passwordHash, ...publicUser } = user;
  return res.json({ success: true, user: publicUser });
});

// 4. LOGOUT ENDPOINT
router.post('/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    activeSessions.delete(token);
  }
  return res.json({ success: true, message: 'Logged out successfully.' });
});

// 5. FORGOT PASSWORD ENDPOINT
router.post('/forgot-password', (req: Request, res: Response) => {
  const { email, newPassword } = req.body;
  if (!email) {
    return res.status(400).json({ success: false, error: 'Email address is required.' });
  }

  const user = userDb.findByEmail(email);
  if (!user) {
    return res.status(404).json({ success: false, error: 'No account registered with this email address.' });
  }

  if (newPassword) {
    if (newPassword.length < 8) {
      return res.status(400).json({ success: false, error: 'New password must be at least 8 characters.' });
    }
    userDb.updatePassword(email, newPassword);
    return res.json({ success: true, message: 'Password reset successful! Please log in with your new credentials.' });
  }

  return res.json({
    success: true,
    message: `Password reset instructions and verification OTP have been dispatched to ${email}.`
  });
});

export default router;
