import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { UserRole, UserAccount } from '../src/types';

export interface StoredUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  salt: string;
  role: UserRole;
  panNumber?: string;
  kycStatus: 'VERIFIED' | 'PENDING' | 'REJECTED';
  createdAt: string;
}

export interface StoredSession {
  token: string;
  userId: string;
  email: string;
  role: UserRole;
  expiresAt: number; // timestamp
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const USERS_FILE = path.join(DB_DIR, 'users_db.json');
const SESSIONS_FILE = path.join(DB_DIR, 'sessions_db.json');

// Ensure database directory exists
function ensureDb() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  if (!fs.existsSync(USERS_FILE)) {
    // Seed default verified users with hashed passwords
    const initialUsers = createInitialUsers();
    fs.writeFileSync(USERS_FILE, JSON.stringify(initialUsers, null, 2), 'utf-8');
  }

  if (!fs.existsSync(SESSIONS_FILE)) {
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify([], null, 2), 'utf-8');
  }
}

// Password hashing using Scrypt with salt
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const userSalt = salt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, userSalt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt: userSalt
  };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const derivedKey = crypto.scryptSync(password, salt, 64);
  const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
  const hashBuffer = Buffer.from(hash, 'hex');
  if (keyBuffer.length !== hashBuffer.length) {
    return false;
  }
  return crypto.timingSafeEqual(keyBuffer, hashBuffer);
}

// Initial demo users with password: "Password@123"
function createInitialUsers(): StoredUser[] {
  const defaultPw = 'Password@123';

  const usersData: Array<Omit<StoredUser, 'passwordHash' | 'salt'>> = [
    {
      id: 'USR-IN-001',
      name: 'Rajesh Sharma',
      email: 'rajesh.sharma@investor.in',
      phone: '+91 98112 34567',
      role: 'CUSTOMER',
      panNumber: 'ABCPS1234F',
      kycStatus: 'VERIFIED',
      createdAt: '2024-01-15T09:00:00Z'
    },
    {
      id: 'USR-IN-002',
      name: 'Priya Patel',
      email: 'priya.patel@wealthops.in',
      phone: '+91 98223 45678',
      role: 'OPERATIONS',
      panNumber: 'BKPPA5678K',
      kycStatus: 'VERIFIED',
      createdAt: '2024-01-20T10:00:00Z'
    },
    {
      id: 'USR-IN-003',
      name: 'Arun Verma',
      email: 'arun.verma@compliance.in',
      phone: '+91 98334 56789',
      role: 'COMPLIANCE',
      panNumber: 'CKPVE9012M',
      kycStatus: 'VERIFIED',
      createdAt: '2024-02-01T11:00:00Z'
    },
    {
      id: 'USR-IN-004',
      name: 'Suresh Gupta',
      email: 'admin@equibalance.in',
      phone: '+91 98445 67890',
      role: 'ADMIN',
      panNumber: 'DKPGU3456N',
      kycStatus: 'VERIFIED',
      createdAt: '2024-01-01T08:00:00Z'
    }
  ];

  return usersData.map(u => {
    const { hash, salt } = hashPassword(defaultPw);
    return {
      ...u,
      passwordHash: hash,
      salt
    };
  });
}

// User CRUD
export function getUsers(): StoredUser[] {
  ensureDb();
  try {
    const content = fs.readFileSync(USERS_FILE, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    console.error('Error reading users db:', err);
    return [];
  }
}

export function saveUsers(users: StoredUser[]) {
  ensureDb();
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
}

export function findUserByEmail(email: string): StoredUser | undefined {
  const users = getUsers();
  const normalized = email.trim().toLowerCase();
  return users.find(u => u.email.toLowerCase() === normalized);
}

export function findUserById(id: string): StoredUser | undefined {
  const users = getUsers();
  return users.find(u => u.id === id);
}

export function createUser(userData: {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  panNumber?: string;
}): StoredUser {
  const users = getUsers();
  const normalizedEmail = userData.email.trim().toLowerCase();

  if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
    throw new Error('A user with this email address already exists.');
  }

  const { hash, salt } = hashPassword(userData.password);
  const newUser: StoredUser = {
    id: `USR-${Date.now().toString().slice(-6)}`,
    name: userData.name.trim(),
    email: normalizedEmail,
    phone: userData.phone.trim(),
    passwordHash: hash,
    salt,
    role: userData.role,
    panNumber: userData.panNumber?.trim().toUpperCase() || 'ABCDE1234F',
    kycStatus: 'VERIFIED',
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  saveUsers(users);
  return newUser;
}

// Session Management
export function getSessions(): StoredSession[] {
  ensureDb();
  try {
    const content = fs.readFileSync(SESSIONS_FILE, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    return [];
  }
}

export function saveSessions(sessions: StoredSession[]) {
  ensureDb();
  fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions, null, 2), 'utf-8');
}

export function createSession(user: StoredUser, rememberMe: boolean = false): string {
  const sessions = getSessions();
  // 30 days if rememberMe, else 24 hours
  const ttlMs = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
  const token = `eq_sess_${crypto.randomBytes(32).toString('hex')}`;

  const newSession: StoredSession = {
    token,
    userId: user.id,
    email: user.email,
    role: user.role,
    expiresAt: Date.now() + ttlMs
  };

  // Remove existing expired sessions or session for same user
  const validSessions = sessions.filter(s => s.expiresAt > Date.now());
  validSessions.push(newSession);
  saveSessions(validSessions);

  return token;
}

export function validateSession(token: string): StoredUser | null {
  if (!token) return null;
  const sessions = getSessions();
  const session = sessions.find(s => s.token === token && s.expiresAt > Date.now());
  if (!session) return null;

  const user = findUserById(session.userId);
  return user || null;
}

export function removeSession(token: string) {
  const sessions = getSessions();
  const remaining = sessions.filter(s => s.token !== token);
  saveSessions(remaining);
}

export function resetUserPassword(email: string, newPassword: string): boolean {
  const users = getUsers();
  const user = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  if (!user) return false;

  const { hash, salt } = hashPassword(newPassword);
  user.passwordHash = hash;
  user.salt = salt;
  saveUsers(users);
  return true;
}
